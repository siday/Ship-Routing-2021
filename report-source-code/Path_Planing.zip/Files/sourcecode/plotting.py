
import matplotlib.pyplot as plt
import Obstacles
import Dijkstra
from Dijkstra import Dijkstra

class Plotting:
    def __init__(self, xI, xG,location):
        self.xI, self.xG = xI, xG
        self.OBS = Obstacles.obstacles(location)
        self.obs = self.OBS.obs_map()

    def update_obs(self, obs):
        self.obs = obs

    def animation(self, path, visited, name):
        self.plot_grid(name)
        self.plot_visited(visited)
        self.plot_path(path)
        plt.show()

    def plot_grid(self, name):
        obs_x = [x[0] for x in self.obs]
        obs_y = [x[1] for x in self.obs]

        plt.plot(self.xI[0], self.xI[1], "bs")
        plt.plot(self.xG[0], self.xG[1], "gs")
        plt.plot(obs_x, obs_y, "sk")
        plt.title(name)
        plt.axis("equal")
    def plot_visited_in_GUI(self,visited):
        '''This function will plot the visited area directly '''
        if self.xI in visited: visited.remove(self.xI)
        if self.xG in visited: visited.remove(self.xG)
        visited_x=[visited[i][0] for i in range(len(visited))]
        visited_y=[visited[i][1] for i in range(len(visited))]
        plt.plot(visited_x,visited_y, color='yellow',marker= 'o',linestyle = 'None')
    def plot_visited(self, visited, cl='yellow'):
        if self.xI in visited:
            visited.remove(self.xI)

        if self.xG in visited:
            visited.remove(self.xG)

        count = 0

        for x in visited:
            count += 1
            plt.plot(x[0], x[1], color=cl, marker='o')
            plt.pause(0.001)
        plt.pause(0.01)

    def plot_path(self, path, cl='r', flag=False):
        path_x = [path[i][0] for i in range(len(path))]
        path_y = [path[i][1] for i in range(len(path))]

        plt.plot(path_x, path_y, linewidth='3', color=cl)

        plt.plot(self.xI[0], self.xI[1], "bs")
        plt.plot(self.xG[0], self.xG[1], "gs")
